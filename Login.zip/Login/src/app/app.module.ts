import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { EditEmployeeComponent } from './crud/employee/edit-employee/edit-employee.component';
import { EmployeeComponent } from './crud/employee/employee.component';
import { HttpClientModule } from '@angular/common/http';
import { DataserviceService } from './service/dataservice.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { LoadingBarRouterModule } from '@ngx-loading-bar/router';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    NavbarComponent,
    EmployeeComponent,
    EditEmployeeComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    NgxSpinnerModule,
    LoadingBarRouterModule,
  ],
  providers: [DataserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
