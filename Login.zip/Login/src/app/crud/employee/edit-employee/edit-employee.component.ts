import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/crud/models/employee.model';
import { EmployeeserviceService } from 'src/app/crud/services/employeeservice.service';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {
  id: number;
  header: string; 
  employees:Employee = {
    id : '',
    Name : '',
    Email :'',
    PhoneNumber :''
  }
  hidden = false;
  nothidden= true;

  // employees: any;

  constructor( private router:Router,private route:ActivatedRoute, private employeeservice :EmployeeserviceService,) { }

  ngOnInit() {
    this.id= +this.route.snapshot.paramMap.get('id');
    console.log(this.id);
    this.header= this.id == 0 ? 'Add Employee' : 'Edit Employee';
    console.log(this.header);
   
    if(this.id !=0)
    {
      this.hidden = true;
      this.nothidden=false;
      console.log('hello', this.id)
      this.employees = this.employeeservice.getEmployee(this.id);
      console.log('Edit Employee', this.employees);
     }
  }


  onSubmit(form :NgForm)
  {
  let employee: Employee ={
    id: parseInt(form.value.id),
    Name :form.value.Name,
    Email :form.value.email,
    PhoneNumber :form.value.phonenumber,
  }
  if(this.id === 0)
  {
    this.employeeservice.onAdd(employee);
  }
  else{
    this.employeeservice.onUpdate(employee);
  }
 
  this.router.navigateByUrl('/view');
  }
  


}
