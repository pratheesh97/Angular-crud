import { Component, OnInit } from '@angular/core';
import { Employee } from '../models/employee.model';
import { EmployeeserviceService } from '../services/employeeservice.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private employeeservice :EmployeeserviceService) { }
  employee : Employee[];
  ngOnInit() {
    this.employee = this.employeeservice.onGet();
  }

  onDelete(id : number)
  {
    this.employeeservice.onDel(id);
  }
  
}
