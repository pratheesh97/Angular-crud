import { Component, OnInit, Output ,EventEmitter} from '@angular/core';
import { FormBuilder, FormControl ,FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { DataserviceService } from '../service/dataservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
@Output() SendData : EventEmitter<any> = new EventEmitter<any>(); 

  LoginForm : FormGroup;
  profiledata: any=[];
  filterData: any={};
  SpinnerType : any;
  SpinnerName : any;
  fieldTextType: boolean;
 

  constructor(private dataservice:DataserviceService,private router:Router,private spinner: NgxSpinnerService, private fb:FormBuilder) { 
    this.SpinnerName = 'sp1';
    this.SpinnerType =  'ball-clip-rotate-multiple';

    this.LoginForm = this.fb.group({
      Email: new FormControl('',[Validators.required,Validators.email]),
      Password: new FormControl('',[ Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$")]),
    });
  
  }

  get f(){return this.LoginForm.controls}

  ngOnInit() {
    sessionStorage.clear();
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  checkLogin(){
    this.profiledata=this.dataservice.signupData;
    this.filterData = this.profiledata.filter( e => e.Email == this.LoginForm.value.Email);
    if ( this.filterData .length != 0 ){
      if ( this.LoginForm.value.Password == this.filterData[0].Password ){
        sessionStorage.setItem("Email", this.filterData[0].Email);
        this.spinner.show(this.SpinnerName);
        setTimeout(() => {
          this.spinner.hide(this.SpinnerName);
          this.router.navigate(['/view']);
        }, 2000);  
      } else {
        alert("Password Incorrect");
      }
    } else {
      alert("Hello Email Id not found");
    }
  }
}
