import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { DataserviceService } from './service/dataservice.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(public router : Router, private dataservice : DataserviceService){}

  canActivate(): boolean{
    
    if(this.dataservice.authChecking()!=null )
    {
      var data= sessionStorage.getItem('Email'); 
        // console.log(data);
        if(data ==='tharmapratheesh@gmail.com')
        {
          return true;
        }else{
          this.router.navigate(['/'])
          return false;
        }
    }
    else{
      this.router.navigate(['/'])
      return false
    }
      }
    
  
}
