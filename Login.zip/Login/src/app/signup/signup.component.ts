import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl ,FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataserviceService } from '../service/dataservice.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  SignupForm : FormGroup;
  fieldTextType: boolean;
  fieldText:boolean;
  submitted :boolean = false;

  constructor(private dataservice:DataserviceService, private router:Router,private fb :FormBuilder) { 
    this.SignupForm = this.fb.group({
      Username: new FormControl('',[Validators.required,Validators.pattern('^[a-zA-Z ]*$')]),
      Email: new FormControl('',[Validators.required,Validators.email]),
      Password: new FormControl('',[Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$")]),
      ConfirmPassword : new FormControl('',[Validators.required, Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$")])
     
    });
  }

  get f(){return this.SignupForm.controls;}

  ngOnInit() {
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }
  
  toggleFieldText(){
    this.fieldText = !this.fieldText;
  }

  

  CheckSignup(){
    this.submitted = true;
    if( this.SignupForm.valid &&
      this.SignupForm.controls.ConfirmPassword.value === this.SignupForm.controls.Password.value ){
        this.dataservice.viewFunction(this.SignupForm.value);
        alert('signup successfully')
        this.router.navigateByUrl('');
    }
    else{
      return
    }
    
  }
  
  

}
