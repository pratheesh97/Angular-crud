import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { EditEmployeeComponent } from './crud/employee/edit-employee/edit-employee.component';
import { EmployeeComponent } from './crud/employee/employee.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';


const routes: Routes = [
  {path :'' ,  component:LoginComponent},
  {path :'signup' ,  component:SignupComponent},
  {
    path : "view",
    component: EmployeeComponent,
  },
  {
    path : "view/employee/edit/:id",
    component: EditEmployeeComponent,canActivate:[AuthGuard]
  },
  {
    path : "view/employee/add/:id",
    component: EditEmployeeComponent, canActivate:[AuthGuard]
  },



  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
