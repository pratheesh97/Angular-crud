import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
 
  loginSuccess = true;
  storage: any;
  value: any;
  public nowDatetime: Date = new Date();
  constructor( private router:Router) {
    setInterval(() => {
      this.nowDatetime = new Date();
    }, 60);
   }

  ngOnInit() {
    this.value=localStorage.getItem('Email');
    if(this.value != null || this.value == '' )
      {
        this.loginSuccess =false;
      }
    }

    receiveData(event)
    {
      console.log(event )
    }
  logout()
  { 
    localStorage.clear();
    this.router.navigateByUrl('');
    this.loginSuccess =true;
  }

}
