import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-observable',
  templateUrl: './observable.component.html',
  styleUrls: ['./observable.component.css']
})
export class ObservableComponent implements OnInit {
  myDestroy: any;

  constructor() { }

  ngOnInit() {
    const myObj$ = new Observable(obs =>{
      console.log('observable start');
      obs.next("100");
      obs.next("200");
      // obs.error('not working');
      obs.next("300");
      // obs.complete();
      // obs.next("400");
      setInterval(() => {
        obs.next('400');
      },1000);
      console.log('observable end');
    });

  
    // myObj$.subscribe(sub => {
    //   console.log(sub);
    // },
    // error =>{                                        //subscribe method
    //   console.log("Error" + error);
    // },
    // () => {
    //   console.log('observable complete');
    // });

    
    this.myDestroy = myObj$.subscribe(sub => {
      console.log(sub);
    },
    error =>{                                        //unsubscribe method
      console.log("Error" + error);
    },
    () => {
      console.log('observable complete');
    });

    this.myDestroy.unsubscribe();
  }

}
