import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LifeCycleComponent } from '../life-cycle.component';
import { AngularHooksComponent } from '../angular-hooks/angular-hooks.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [AngularHooksComponent,
    LifeCycleComponent],
  imports: [
    CommonModule,FormsModule
  ]
})
export class LifecycleModule { }
