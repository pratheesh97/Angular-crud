import { Component, OnInit, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.css']
})
export class LifeCycleComponent implements OnInit {
  @Input() value: string;

  setTimeinterval = null;

  constructor() { 
    console.log('constructor!!!')
  }

  ngOnInit() {
    console.log("NgOnInit!!!")
    this.setTimeinterval = setInterval(() => {
      console.log(new Date()); }, 1000)
  }

  ngOnDestroy()
  {
    if(this.setTimeinterval )
    {
      console.log('ngDestroy')
      clearInterval(this.setTimeinterval);
    }
  }

  // ngOnChanges() {
  //   console.log("NgOnchanges!!!")
  // }

  // ngDoCheck() {
  //   console.log("NgDoCheck!!!")
  // }

  // ngAfterContentInit(){
  //   console.log("NgAfterContentInit!!!")
  // }

  // ngAfterContentChecked(){
  //   console.log("NgAfterContentChecked!!!")
  // }

  // ngAfterViewInit(){
  //   console.log("NgAfterViewInit!!!")
  // }

  // ngAfterViewChecked(){
  //   console.log("NgAfterViewChecked!!!")
  // }

  

}
