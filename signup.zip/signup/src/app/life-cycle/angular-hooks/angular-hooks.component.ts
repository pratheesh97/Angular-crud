import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-angular-hooks',
  templateUrl: './angular-hooks.component.html',
  styleUrls: ['./angular-hooks.component.css']
})
export class AngularHooksComponent implements OnInit {

  showLifeCycle : boolean = false;

  value:string ="pratheesh"

  constructor() { }

  ngOnInit() {
  }

  onShowOrHide()
  {
    this.showLifeCycle = !this.showLifeCycle;
  }

}
