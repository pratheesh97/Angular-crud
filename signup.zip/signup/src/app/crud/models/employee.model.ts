export class Employee{
    public id : any;
    public Name : string;
    public Email : string;
    public PhoneNumber : any;
}
