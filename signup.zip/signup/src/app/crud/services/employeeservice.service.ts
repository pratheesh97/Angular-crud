import { Injectable } from '@angular/core';
import { Employee } from '../models/employee.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeeserviceService {
  employee : Employee[] =[
   {
      id : 1,
      Name : "Pratheesh",
      Email : "xxx@gmsil.com",
      PhoneNumber : 9844398344
    },
    {
      id : 2,
      Name : "Mugesh",
      Email : "yyy@gmsil.com",
      PhoneNumber : 9049494949
    },

  ];
  constructor() { }

  onGet(){
    return this.employee;
  }

  onAdd(employee : Employee){
    this.employee.push(employee);
  }

  onDel(id :number)
  {
   let employees=this.employee.find(x=>x.id ===id);
   let index= this.employee.indexOf(employees,0);
   this.employee.splice(index,1);

  }

  getEmployee(id)
  { 
    console.log(this.employee);
    console.log("__________id__", id);
    return this.employee.find(x=>x.id === id);
    
  }

  onUpdate(employee : Employee)
  {
   let oldEmployee = this.employee.find(x=>x.id === employee.id);
   oldEmployee.Name=employee.Name;
   oldEmployee.Email= employee.Email;
   oldEmployee.PhoneNumber =employee.PhoneNumber;
  }
}
