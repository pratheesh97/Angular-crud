import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders,  } from '@angular/common/http';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class DataserviceService {
  signupData: any = []; 

  constructor() { }

  ngOnInit(): void {
    console.log(this.signupData);
  }

  viewFunction(data){
    this.signupData.push(data);
    console.log(this.signupData)
  }

  authChecking() {
    return sessionStorage.getItem('Email'); 
 }

}
