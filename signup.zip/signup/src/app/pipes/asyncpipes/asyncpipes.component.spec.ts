import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AsyncpipesComponent } from './asyncpipes.component';

describe('AsyncpipesComponent', () => {
  let component: AsyncpipesComponent;
  let fixture: ComponentFixture<AsyncpipesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AsyncpipesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AsyncpipesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
