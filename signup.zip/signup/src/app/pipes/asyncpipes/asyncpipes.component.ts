import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-asyncpipes',
  templateUrl: './asyncpipes.component.html',
  styleUrls: ['./asyncpipes.component.css']
})
export class AsyncpipesComponent implements OnInit {

  constructor(public http :HttpClient) { }

  JsonData: any = []; 
  

  ngOnInit() {
  this.JsonData = this.http.get('https://jsonplaceholder.typicode.com/todos/1');

  }

}
