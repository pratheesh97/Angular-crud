import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InbuildCustomPipeComponent } from './inbuild-custom-pipe.component';

describe('InbuildCustomPipeComponent', () => {
  let component: InbuildCustomPipeComponent;
  let fixture: ComponentFixture<InbuildCustomPipeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InbuildCustomPipeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InbuildCustomPipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
