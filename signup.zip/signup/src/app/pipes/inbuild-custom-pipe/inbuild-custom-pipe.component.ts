import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-inbuild-custom-pipe',
  templateUrl: './inbuild-custom-pipe.component.html',
  styleUrls: ['./inbuild-custom-pipe.component.css']
})

export class InbuildCustomPipeComponent implements OnInit {

  day = new Date();
  num = 23467.87;
  num1 = 0.60;
  num2 = 230.00;
  obj ={ name :'pratheesh', age : 23};
  arr= [1,2,3];
  name='tharmapratheesh';

  constructor() { }

  ngOnInit() {
  }

}
