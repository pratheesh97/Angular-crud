import { Component, OnInit } from '@angular/core';
import { FormControl ,FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataserviceService } from '../service/dataservice.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  SignupForm = new FormGroup({
    Email: new FormControl('',Validators.required),
    Password: new FormControl('',Validators.required),
    Address: new FormControl('',Validators.required),
    Address2: new FormControl('',Validators.required),
    City: new FormControl('',Validators.required),
    State: new FormControl('',Validators.required),
    Zip: new FormControl('',Validators.required),
  });
  get Email(){return this.SignupForm.get('Email')}
  get Password(){return this.SignupForm.get('Password')}
  get Address(){return this.SignupForm.get('Address')}
  get Address2(){return this.SignupForm.get('Address2')}
  get City(){return this.SignupForm.get('City')}
  get State(){return this.SignupForm.get('State')}
  get Zip(){return this.SignupForm.get('Zip')}

  constructor(private dataservice:DataserviceService, private router:Router) { }

  ngOnInit() {
  }

  CheckSignup(){
    this.dataservice.viewFunction(this.SignupForm.value);
    alert('signup successfully')
    this.router.navigateByUrl('');
  }

  

}
