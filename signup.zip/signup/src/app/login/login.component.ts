import { Component, OnInit, Output ,EventEmitter} from '@angular/core';
import { FormControl ,FormGroup,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { DataserviceService } from '../service/dataservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
@Output() SendData : EventEmitter<any> = new EventEmitter<any>(); 

  LoginForm = new FormGroup({
    Email: new FormControl('',Validators.required ),
    Password: new FormControl('', Validators.required),
  });

  get Email(){return this.LoginForm.get('Email')}
  get Password(){return this.LoginForm.get('Password')}

  profiledata: any=[];
  filterData: any={};
  constructor(private dataservice:DataserviceService,private router:Router, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    sessionStorage.clear();
  }

  checkLogin(){
    this.profiledata=this.dataservice.signupData;
    this.filterData = this.profiledata.filter( e => e.Email == this.LoginForm.value.Email);
    if ( this.filterData .length != 0 ){
      if ( this.LoginForm.value.Password == this.filterData[0].Password ){
        sessionStorage.setItem("Email", this.filterData[0].Email);
        this.SendData.emit('loginsuccess')
        this.spinner.show();
        this.router.navigate(['/view']);
        this.spinner.hide();
      } else {
        alert("Password Incorrect");
      }
    } else {
      alert("Hello EMail ID not found");
    }
  }
}
