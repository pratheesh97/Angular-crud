import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
 @Input() childname ="";
  
 @Output() SendEMitterMessage = new EventEmitter();
  constructor() { }
 
  ngOnInit() {
  }

  SendMessage(e){
    this.SendEMitterMessage.emit(e.target.value);
  }
}
