import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StaticFoodSiteComponent } from './static-food-site.component';

describe('StaticFoodSiteComponent', () => {
  let component: StaticFoodSiteComponent;
  let fixture: ComponentFixture<StaticFoodSiteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StaticFoodSiteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StaticFoodSiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
