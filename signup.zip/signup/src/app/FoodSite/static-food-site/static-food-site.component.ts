import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-static-food-site',
  templateUrl: './static-food-site.component.html',
  styleUrls: ['./static-food-site.component.css']
})
export class StaticFoodSiteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
