import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { NavbarComponent } from './navbar/navbar.component';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { EditEmployeeComponent } from './crud/employee/edit-employee/edit-employee.component';
import { EmployeeComponent } from './crud/employee/employee.component';
import { InteractionModule } from './Component-Interaction/interaction.module';
import { StaticFoodSiteComponent } from './FoodSite/static-food-site/static-food-site.component';
import { InbuildCustomPipeComponent } from './pipes/inbuild-custom-pipe/inbuild-custom-pipe.component';
import { AsyncpipesComponent } from './pipes/asyncpipes/asyncpipes.component';
import { CustomPipe } from './pipes/inbuild-custom-pipe/custom.pipe';
import { HttpClientModule } from '@angular/common/http';
import { LifecycleModule } from './life-cycle/lifecycle/lifecycle.module';
import { ObservableComponent } from './observable/observable.component';
import { DataserviceService } from './service/dataservice.service';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    NavbarComponent,
    EmployeeComponent,
    EditEmployeeComponent,
    StaticFoodSiteComponent,
    InbuildCustomPipeComponent,
    AsyncpipesComponent,
    CustomPipe,
    ObservableComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    InteractionModule,
    HttpClientModule,
    LifecycleModule,
    NgxSpinnerModule
  ],
  providers: [DataserviceService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
