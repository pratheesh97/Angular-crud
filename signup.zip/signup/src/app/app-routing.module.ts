import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { ParentComponent } from './Component-Interaction/parent/parent.component';
import { EditEmployeeComponent } from './crud/employee/edit-employee/edit-employee.component';
import { EmployeeComponent } from './crud/employee/employee.component';
import { StaticFoodSiteComponent } from './FoodSite/static-food-site/static-food-site.component';
import { AngularHooksComponent } from './life-cycle/angular-hooks/angular-hooks.component';
import { LoginComponent } from './login/login.component';
import { ObservableComponent } from './observable/observable.component';
import { AsyncpipesComponent } from './pipes/asyncpipes/asyncpipes.component';
import { InbuildCustomPipeComponent } from './pipes/inbuild-custom-pipe/inbuild-custom-pipe.component';
import { SignupComponent } from './signup/signup.component';


const routes: Routes = [
  {path :'' ,  component:LoginComponent},
  {path :'signup' ,  component:SignupComponent},
  {
    path : "view",
    component: EmployeeComponent, canActivate:[AuthGuard]
  },
  {
    path : "view/employee/edit/:id",
    component: EditEmployeeComponent, canActivate:[AuthGuard]
  },
  {
    path : "view/employee/add/:id",
    component: EditEmployeeComponent, canActivate:[AuthGuard]
  },
  {
    path : "parent",
    component: ParentComponent, canActivate:[AuthGuard]
  },
  {
    path : "foodsite",
    component: StaticFoodSiteComponent, canActivate:[AuthGuard]
  },
  {
    path : "custompipe",
    component: InbuildCustomPipeComponent, canActivate:[AuthGuard]
  },
  {
    path : "asyncpipe",
    component: AsyncpipesComponent, canActivate:[AuthGuard]
  },
  {
    path : "hooks",
    component: AngularHooksComponent, canActivate:[AuthGuard]
  },
  {
    path : "observer",
    component: ObservableComponent, canActivate:[AuthGuard]
  },

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
